---
name: IST Nexus
colors:
  surface: '#0e1322'
  surface-dim: '#0e1322'
  surface-bright: '#343949'
  surface-container-lowest: '#090e1c'
  surface-container-low: '#161b2b'
  surface-container: '#1a1f2f'
  surface-container-high: '#25293a'
  surface-container-highest: '#2f3445'
  on-surface: '#dee1f7'
  on-surface-variant: '#e4beba'
  inverse-surface: '#dee1f7'
  inverse-on-surface: '#2b3040'
  outline: '#ab8986'
  outline-variant: '#5b403e'
  surface-tint: '#ffb3ad'
  primary: '#ffb3ad'
  on-primary: '#68000a'
  primary-container: '#ff5451'
  on-primary-container: '#5c0008'
  inverse-primary: '#b91a24'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#93ccff'
  on-tertiary: '#003351'
  tertiary-container: '#3198dc'
  on-tertiary-container: '#002c47'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad7'
  primary-fixed-dim: '#ffb3ad'
  on-primary-fixed: '#410004'
  on-primary-fixed-variant: '#930013'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#0e1322'
  on-background: '#dee1f7'
  surface-variant: '#2f3445'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-inline:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 2rem
  margin-mobile: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system serves a modern, rigorous, technical higher-education demographic—computer science scholars, applied engineers, and academic faculty. The aesthetic balances high-density information architecture with the electric atmosphere of late-night technical labs. It evokes intellectual focus, precision, and technological command.

The visual style blends **Deep Technical Minimalism** with **Controlled Glassmorphism**. Dark slate-to-navy fields eliminate glare during marathon coding and research sessions. Crisp geometric typography ensures immediate legibility for dense syllabus schedules, live code reviews, and academic transcripts. Primary key actions stand out with authoritative crimson, while dynamic data streams and status states leverage luminous cyan, azure, and semantically tuned signals. Subtle translucent rims replace heavy elevation shadows, giving surface containers an illuminated, instrument-grade presence.

## Colors

The palette operates in a default dark state engineered around high legibility, deep optical depth, and sharp informational hierarchy.

- **Background Canvas (`#060913`)**: The absolute base layer across all viewports.
- **Surface Elevation 1 (`#0a0f1e`)**: Primary card surfaces, side navigations, and academic dashboards.
- **Surface Elevation 2 (`#0f172a`)**: Modals, popovers, table headers, and focused panels.
- **Primary Action Accent (`#ef4444` / Hover `#dc2626`)**: Reserved for decisive, high-value operations—exam submissions, course enrollments, grade verifications, and urgent institutional alerts.
- **Signal Accents**:
  - **Electric Cyan (`#06b6d4`) & Azure (`#0284c7`, `#38bdf8`)**: Primary interactive links, live active states, timetable blocks, and metric progressions.
  - **Emerald Green (`#10b981`)**: Passing marks, active semesters, and verified prerequisites.
  - **Amber Gold (`#f59e0b`)**: Deadlines within 48 hours, pending review, and advisory alerts.
  - **Royal Violet (`#8b5cf6`)**: Honors cohorts, lab sessions, and research publications.
- **Text & Foreground**:
  - **Headings & Primary Data**: `#f8fafc` (high contrast).
  - **Secondary Information**: `#94a3b8` (balanced legibility).
  - **Muted / Inactive**: `#475569`.
- **Structural Glass Borders**: `rgba(56, 189, 248, 0.15)` across elevated panels to provide crisp perimeter definition without visual heaviness.

## Typography

Typography establishes clear cognitive order across dense dashboards.

- **Plus Jakarta Sans** governs all titles, section headliners, metric cards, and event banners. Its modern geometric curves lend energy and institutional stature.
- **Inter** provides high rendering precision for long-form curriculum text, syllabus breakdowns, schedule timelines, and tabular data.
- Numbers, grades, GPA scores, and course IDs inherit tabular figures (`tnum`) to maintain clean baseline alignment across vertical tables.
- All display scales scale down cleanly via mobile variables on screens under 768px to eliminate line wrapping in compact viewports.

## Layout & Spacing

The collegiate portal relies on a 12-column responsive fluid grid structured for multi-panel workflows:

- **Desktop (≥ 1280px)**: 12 columns with `2rem` gutters and `3rem` canvas margins. Persistent 260px left sidebar for campus navigation, with modular widget spans (4-col calendar, 8-col active coursework).
- **Tablet (768px - 1279px)**: 8 columns with `1.5rem` gutters and `2rem` outer margins. Collapsible icon rail navigation; tables shift to horizontally scrollable modules.
- **Mobile (< 768px)**: 4 columns with `1rem` gutters and `1rem` margins. Navigation collapses into an app-bar bottom sheet or top drawer; widgets stack into single vertical cards.
- **Density Controls**: Standard views use `space-md` (`1rem`) internal padding. High-density data tables and calendar time blocks drop to `space-xs` and `space-sm` (`0.25rem` to `0.5rem`) gaps to optimize visible information per screen.

## Elevation & Depth

Visual hierarchy is constructed through **Tonal Surface Stacking** coupled with **Translucent Rims**, rather than traditional heavy drop shadows.

- **Base Layer (`#060913`)**: Canvas background. Flat and non-reflective.
- **Level 1 Panels (`#0a0f1e`)**: Academic calendar containers, course index blocks, and standard portal modules. Encased in a `1px` border of `rgba(56, 189, 248, 0.15)`. No drop shadow.
- **Level 2 Floating Elements (`#0f172a`)**: Filter popovers, contextual tooltips, flyout grade breakdowns, and interactive dropdowns. Enhanced with `1px` border of `rgba(56, 189, 248, 0.28)` and an ambient diffusion: `0 12px 32px -4px rgba(2, 6, 23, 0.75)`.
- **Level 3 High Priority Modals**: Direct exam alerts and confirmation drawers. Bordered with a `1px` subtle highlight of `rgba(239, 68, 68, 0.35)` to convey immediate operational focus.
- **Glassmorphic Overlays**: Sticky headers and floating action bars use `backdrop-filter: blur(12px)` over a `rgba(10, 15, 30, 0.8)` background.

## Shapes

The design system adopts a balanced **Rounded (`2`)** shape architecture:

- **Base Components (0.5rem / 8px)**: Buttons, form controls, calendar event chips, table row selections, and status pills.
- **Panels & Containers (1rem / 16px)**: Course cards, academic transcripts, schedule organizers, and analytical charts (`rounded-lg`).
- **Overlays & Dialogs (1.5rem / 24px)**: Modal overlays, command palettes, and primary portal banners (`rounded-xl`).
- **Badges & Avatars**: True pill styling (`9999px`) to immediately demarcate profile identity and status indicators from structural interactive boxes.

## Components

### Buttons
- **Primary Action (Crimson)**: Background `#ef4444`, text `#ffffff`, font-weight `600`. Hover `#dc2626`. Focus ring `2px solid #38bdf8`. Reserved for irreversible or definitive institutional submissions.
- **Secondary (Cyan Ghost)**: Background `transparent`, border `1px solid rgba(6, 182, 212, 0.4)`, text `#38bdf8`. Hover background `rgba(6, 182, 212, 0.1)`.
- **Subtle / Neutral**: Background `#0f172a`, border `1px solid rgba(56, 189, 248, 0.15)`, text `#f8fafc`. Hover border `rgba(56, 189, 248, 0.4)`.

### Chips & Status Badges
- Built with a `0.25rem` vertical and `0.75rem` horizontal padding, styled as full pills (`9999px`).
- **Enrolled / Success**: Background `rgba(16, 185, 129, 0.12)`, text `#34d399`, border `1px solid rgba(16, 185, 129, 0.25)`.
- **Pending Review**: Background `rgba(245, 158, 11, 0.12)`, text `#fbbf24`, border `1px solid rgba(245, 158, 11, 0.25)`.
- **Core Requirement**: Background `rgba(6, 182, 212, 0.12)`, text `#38bdf8`, border `1px solid rgba(6, 182, 212, 0.25)`.
- **Honors Track**: Background `rgba(139, 92, 246, 0.12)`, text `#c084fc`, border `1px solid rgba(139, 92, 246, 0.25)`.

### Academic Tables
- **Container**: Elevated `#0a0f1e` background wrapped in `1px solid rgba(56, 189, 248, 0.15)` with `rounded-lg` corners.
- **Headers**: Surface `#0f172a`, uppercase `label-sm` text color `#94a3b8`, separated with a subtle bottom hairline `1px solid rgba(56, 189, 248, 0.1)`.
- **Rows**: Alternating subtle backgrounds or pure borders. Row hover triggers background `rgba(56, 189, 248, 0.04)`. Numeric data, course codes, and timestamps styled in tabular alignment.

### Interactive Calendar Event Cards
- Individual schedule blocks nested inside timetable views.
- **Surface**: Background `rgba(15, 23, 42, 0.7)` with `backdrop-filter: blur(8px)`.
- **Accent Indicator**: A `3px` solid left edge border colored by subject tag (e.g., `#06b6d4` for Labs, `#8b5cf6` for Lectures, `#ef4444` for Exams).
- **Metadata**: Course code, hall number, and time range formatted in `body-sm` with active participants count badge.

### Input Fields & Controls
- **Inputs**: Background `#060913`, border `1px solid rgba(56, 189, 248, 0.2)`, text `#f8fafc`, placeholder `#475569`. Focused state triggers border `#38bdf8` with a soft outer glow `0 0 0 3px rgba(56, 189, 248, 0.15)`.
- **Checkboxes & Radios**: Base background `#0a0f1e` with cyan accent fill (`#0284c7`) and white checkmarks when active.

### Cards
- Surface background `#0a0f1e`, border `1px solid rgba(56, 189, 248, 0.15)`, inner padding `space-lg`.
- Header area features a distinct modular title with trailing badge or action menu, followed by body metrics and a clear footer divider.